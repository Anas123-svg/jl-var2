// src/components/Newsletter.tsx
// Join Our List — a single centred column. Static, no motion.

import { useState, type FormEvent } from 'react'
import { joinList } from '../data/content'

export default function Newsletter() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!email) return
    setSent(true)
  }

  return (
    <section id="newsletter" className="border-t border-border-warm bg-divider text-near-black">
      <div className="mx-auto max-w-[560px] px-5 py-16 text-center sm:px-6 sm:py-20 lg:py-[clamp(88px,11vh,136px)]">
        <p className="font-ui text-[10px] font-medium uppercase tracking-[0.3em] text-secondary sm:text-[11px]">
          {joinList.label}
        </p>

        <h2 className="mt-4 font-display text-[clamp(28px,3.2vw,46px)] uppercase leading-[0.98] tracking-[0.02em]">
          {joinList.title}
        </h2>

        <p className="mx-auto mt-5 max-w-[440px] font-body text-[14px] leading-[1.75] text-secondary sm:text-[15px]">
          {joinList.body}
        </p>

        {sent ? (
          <p className="mt-9 font-body text-[14px] italic text-near-black sm:text-[15px]">
            Thank you — you&apos;re on the list.
          </p>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="mx-auto mt-9 flex max-w-[440px] items-center gap-4 border-b border-near-black/40 pb-2.5 focus-within:border-near-black"
          >
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your email address"
              aria-label="Email address"
              className="min-w-0 flex-1 bg-transparent py-1.5 text-left font-body text-[15px] text-near-black placeholder:text-near-black/35 focus:outline-none"
            />

            <button
              type="submit"
              className="shrink-0 font-ui text-[10px] font-medium uppercase tracking-[0.28em] text-near-black sm:text-[11px]"
            >
              Subscribe →
            </button>
          </form>
        )}

        <p className="mt-5 font-body text-[12px] italic text-secondary">
          No noise. Unsubscribe anytime.
        </p>
      </div>
    </section>
  )
}
