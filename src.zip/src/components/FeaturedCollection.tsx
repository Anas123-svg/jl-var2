// src/components/FeaturedCollection.tsx

import { Link } from 'react-router-dom'

const pieces = [
  {
    id: 'w1',
    label: 'Collection',
    title: 'New Collection',
    caption: 'Archival pigment prints · Spring 2026',
    to: '/shop',
    image:
      'https://images.unsplash.com/photo-1549490349-8643362247b5?auto=format&fit=crop&w=1200&q=90',
  },
  {
    id: 'w2',
    label: 'Series',
    title: 'The Making of Grief',
    caption: 'Untitled No. 7 · London, 2026',
    to: '/press',
    image:
      'https://images.unsplash.com/photo-1577083552431-6e5fd01aa342?auto=format&fit=crop&w=1200&q=90',
  },
  {
    id: 'w3',
    label: 'Study',
    title: 'Body of Light',
    caption: 'Silver gelatin print · 2025',
    to: '/shop',
    image:
      'https://images.unsplash.com/photo-1543857778-c4a1a3e0b2eb?auto=format&fit=crop&w=1200&q=90',
  },
  {
    id: 'w4',
    label: 'Archive',
    title: 'Quiet Remains',
    caption: 'Mixed media on paper · 2026',
    to: '/shop',
    image:
      'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?auto=format&fit=crop&w=1200&q=90',
  },
]

export default function FeaturedCollection() {
  return (
    <section
      id="work"
      className="border-t border-border-warm bg-warm-white text-near-black"
    >
      <div className="mx-auto max-w-[1700px] px-5 py-12 sm:px-7 sm:py-14 lg:px-[clamp(36px,4vw,72px)] lg:py-[clamp(48px,6vh,72px)]">
        {/* Compact header */}
        <div className="grid gap-5 border-b border-border-warm pb-5 md:grid-cols-[minmax(0,1fr)_minmax(260px,420px)] md:items-end md:gap-12">
          <div>
            <p className="font-ui text-[9px] font-medium uppercase tracking-[0.3em] text-secondary sm:text-[10px]">
              The Work
            </p>

            <h2 className="mt-2 font-display text-[clamp(28px,3vw,46px)] uppercase leading-[0.96] tracking-[0.02em]">
              Selected Pieces
            </h2>
          </div>

          <div className="flex flex-col gap-3 md:items-end md:text-right">
            <p className="max-w-[400px] font-body text-[12px] leading-[1.55] text-secondary sm:text-[13px]">
              Recent works and selected pieces from the studio archive.
            </p>

            <Link
              to="/shop"
              className="group inline-flex w-fit items-center gap-2 font-ui text-[9px] font-medium uppercase tracking-[0.27em] sm:text-[10px]"
            >
              <span className="border-b border-near-black pb-0.5">
                View Collection
              </span>

              <span
                aria-hidden="true"
                className="transition-transform duration-300 group-hover:translate-x-1"
              >
                →
              </span>
            </Link>
          </div>
        </div>

        {/* Compact four-piece gallery */}
        <div className="mt-7 grid gap-x-5 gap-y-9 sm:grid-cols-2 lg:mt-9 lg:grid-cols-4 lg:gap-x-[clamp(18px,2vw,32px)]">
          {pieces.map((piece, index) => (
            <Link
              key={piece.id}
              to={piece.to}
              className="group block"
              aria-label={`View ${piece.title}`}
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-divider">
                <img
                  src={piece.image}
                  alt={piece.title}
                  loading="lazy"
                  decoding="async"
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.03]"
                />

                <div className="pointer-events-none absolute inset-0 bg-near-black/0 transition-colors duration-500 group-hover:bg-near-black/[0.04]" />
              </div>

              <div className="mt-3 border-t border-border-warm pt-3">
                <div className="flex items-center justify-between gap-4">
                  <p className="font-ui text-[8px] font-medium uppercase tracking-[0.27em] text-secondary sm:text-[9px]">
                    {piece.label}
                  </p>

                  <p className="font-ui text-[8px] tracking-[0.22em] text-secondary/65 sm:text-[9px]">
                    {String(index + 1).padStart(2, '0')}
                  </p>
                </div>

                <h3 className="mt-2 font-display text-[17px] uppercase leading-[1.05] tracking-[0.02em] transition-opacity duration-300 group-hover:opacity-60 sm:text-[19px]">
                  {piece.title}
                </h3>

                <p className="mt-1 font-body text-[11px] italic leading-[1.45] text-secondary sm:text-[12px]">
                  {piece.caption}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}