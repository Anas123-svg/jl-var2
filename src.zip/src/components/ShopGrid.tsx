// src/components/ShopGrid.tsx
// Prints & Editions — spacious editorial shop layout.

import { Link } from 'react-router-dom'
import { shopPage } from '../data/content'

const productImages: Record<string, string> = {
  p1: 'https://images.unsplash.com/photo-1549490349-8643362247b5?auto=format&fit=crop&w=1200&q=90',
  p2: 'https://images.unsplash.com/photo-1543857778-c4a1a3e0b2eb?auto=format&fit=crop&w=1200&q=90',
  p3: 'https://images.unsplash.com/photo-1531058020387-3be344556be6?auto=format&fit=crop&w=1200&q=90',
  p4: 'https://images.unsplash.com/photo-1577083552431-6e5fd01aa342?auto=format&fit=crop&w=1200&q=90',
  p5: 'https://images.unsplash.com/photo-1561214115-f2f134cc4912?auto=format&fit=crop&w=1200&q=90',
  p6: 'https://images.unsplash.com/photo-1577083288073-40892c0860a4?auto=format&fit=crop&w=1200&q=90',
}

export default function ShopGrid() {
  return (
    <section
      id="shop"
      className="border-t border-border-warm bg-warm-white text-near-black"
    >
      <div className="mx-auto max-w-[1700px] px-5 py-14 sm:px-7 sm:py-16 lg:px-[clamp(40px,5vw,88px)] lg:py-[clamp(68px,8vh,96px)]">
        <div className="grid gap-12 lg:grid-cols-[minmax(230px,0.62fr)_minmax(0,2.38fr)] lg:gap-[clamp(64px,7vw,120px)]">
          {/* Left editorial column */}
          <div className="border-b border-border-warm pb-10 lg:flex lg:min-h-full lg:flex-col lg:border-b-0 lg:border-r lg:pb-0 lg:pr-[clamp(48px,5vw,84px)]">
            <div>
              <p className="font-ui text-[9px] font-medium uppercase tracking-[0.32em] text-secondary sm:text-[10px]">
                The Shop
              </p>

              <h2 className="mt-4 max-w-[350px] font-display text-[clamp(30px,3.2vw,50px)] uppercase leading-[0.95] tracking-[0.02em]">
                Prints &amp; Editions
              </h2>

              <p className="mt-7 max-w-[330px] font-body text-[12px] leading-[1.75] text-secondary sm:text-[13px]">
                {shopPage.intro}
              </p>
            </div>

            {/* Intentional empty space between intro and shop details */}
            <div className="mt-10 lg:mt-auto lg:pt-20">
              <div className="h-px w-10 bg-border-warm" />

              <p className="mt-5 max-w-[270px] font-ui text-[8px] font-medium uppercase leading-[2] tracking-[0.23em] text-secondary sm:text-[9px]">
                Signed &amp; numbered
                <br />
                Certificate included
                <br />
                Ships worldwide
              </p>

              <Link
                to="/shop"
                className="group mt-7 inline-flex items-center gap-3 font-ui text-[9px] font-medium uppercase tracking-[0.28em] text-near-black sm:text-[10px]"
              >
                <span className="border-b border-near-black pb-1">
                  Shop All Editions
                </span>

                <span
                  aria-hidden="true"
                  className="transition-transform duration-300 group-hover:translate-x-1"
                >
                  →
                </span>
              </Link>
            </div>
          </div>

          {/* Product area */}
          <div>
            <div className="grid gap-x-7 gap-y-12 sm:grid-cols-2 xl:grid-cols-3 xl:gap-x-[clamp(28px,3vw,48px)] xl:gap-y-16">
              {shopPage.products.map((product, index) => (
                <Link
                  key={product.id}
                  to="/shop"
                  className="group block"
                  aria-label={`View ${product.title}`}
                >
                  <div className="relative aspect-[4/3] overflow-hidden bg-divider">
                    <img
                      src={productImages[product.id]}
                      alt={product.title}
                      loading="lazy"
                      decoding="async"
                      className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.025]"
                    />

                    <div className="pointer-events-none absolute inset-0 bg-near-black/0 transition-colors duration-500 group-hover:bg-near-black/[0.035]" />

                    <span className="absolute left-3 top-3 bg-warm-white/90 px-2.5 py-1.5 font-ui text-[8px] font-medium tracking-[0.2em] text-near-black backdrop-blur-sm">
                      {String(index + 1).padStart(2, '0')}
                    </span>
                  </div>

                  <div className="mt-4 border-t border-border-warm pt-4">
                    <div className="flex items-start justify-between gap-6">
                      <h3 className="min-w-0 font-display text-[17px] uppercase leading-[1.08] tracking-[0.02em] text-near-black transition-opacity duration-300 group-hover:opacity-60 sm:text-[18px]">
                        {product.title}
                      </h3>

                      <p className="shrink-0 pt-0.5 font-ui text-[11px] font-medium text-near-black sm:text-[12px]">
                        {product.price}
                      </p>
                    </div>

                    <div className="mt-2 flex items-start justify-between gap-6">
                      <p className="min-w-0 max-w-[210px] font-body text-[11px] italic leading-[1.55] text-secondary sm:text-[12px]">
                        {product.meta}
                      </p>

                      <p className="shrink-0 pt-0.5 font-ui text-[8px] font-medium uppercase tracking-[0.21em] text-secondary sm:text-[9px]">
                        {product.edition}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            {/* Quiet closing line */}
            <div className="mt-14 border-t border-border-warm pt-5 lg:mt-16">
              <p className="max-w-[520px] font-body text-[11px] leading-[1.65] text-secondary sm:text-[12px]">
                Each edition is produced in limited quantities and accompanied
                by a signed certificate of authenticity.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}